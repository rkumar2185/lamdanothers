import java.util.Scanner;

/*: Modify the Lab assignment 2.3 to validate the full name of an employee.
 Create and throw a user defined exception if firstName and lastName is blank. */

class NameException extends Exception {

	public NameException(String str) {
		System.out.println(str);
	}
}

public class ExceptnHandling {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("FirstName: ");
		String s = sc.next();

		System.out.println("LastName: ");
		String s1 = sc.next();
		// TODO Auto-generated method stub
		try {
			if (s == null && s1 == null)
				throw new NameException("No name !!!!!");
			else
				System.out.println("Wow got your name");

		} catch (NameException a) {
			System.out.println(a);
		}

	}
}
