import java.util.function.Consumer;


@FunctionalInterface
interface MyInter {
	String spaceBetween(String s);
}

public class StringSpaceLamda {

	public static void main( String[] args ) {

	        MyInter myInterface = (str) -> {

	               String result = "";
	          //  char ch[] =x.toCharArray();
	        	for (int i = 0; i < str.length(); i++) {
	        		if(i%2!=0)
	        			 result += " " + str.charAt(i)+" ";
	        		else 
	        			 result += str.charAt(i);
	        		
	        		//return result;
	        	}
				return result;};
	        	 System.out.println("Lambda Space = "
	        	 		+ "" + myInterface.spaceBetween("Lambda"));
	        
}
}
//import java.util.function.BiFunction;

/* Write a method that uses lambda expression to format a given string,
 *  where a space is inserted between each character of string.  For ex.,
 if input is �CG�, then expected output is �C G�. */
/*
 public class StringSpaceLamda {

 public static void main(String[] args) {

 Consumer<String> obj = (x)-> {
 char ch[] =x.toCharArray();
 for (int i = 0; i < ch.length; i++) {
 if(i%2!=0)
 System.out.println(" ");
 else 
 System.out.println(ch[i]);
 }

 //String ravi;
 System.out.println(obj.accept(ravi);

 };
 }
 }*/

/*
 @FunctionalInterface
 interface MyInterface {

 String reverse(String n);
 }

 public class StringSpaceLamda  {

 public static void main( String[] args ) {

 MyInterface myInterface = (str) -> {

 String result = "";
 for (int i = str.length()-1; i >= 0 ; i--)
 result += str.charAt(i);
 return result;
 };

 System.out.println("Lambda reversed = " + myInterface.reverse("Lambda"));
 }

 }
 */

