import java.util.function.BiFunction;

// Write a lambda expression which accepts x and y numbers and return xy. 


public class LamdaAdd {
	
	
	public static void main(String[] args) {
		BiFunction<Integer, Integer, Integer> obj = (x ,y)-> (int)Math.pow(x,y);
		
		System.out.println(obj.apply(2,3));
	}
}






/*


public class LamdaAdd {
	
	interface Functn
	{
		double Poweroperation(double x , double y);
	}

	public static void main(String[] args) {

		
		Functn power = (double x ,double y) -> Math.pow(x, y);
		
		LamdaAdd tobj = new LamdaAdd(); 
		  
        System.out.println("Operation is " + 
                          ((Functn) tobj).Poweroperation(6.0,3.0)); 
	}
		
		

	
}


public class LamdaAdd 
{ 
    interface FuncInter1 
    { 
        int operation(int a, int b); 
    } 
  
    interface FuncInter2 
    { 
        void sayMessage(String message); 
    } 
  
    private int operate(int a, int b, FuncInter1 fobj) 
    { 
        return fobj.operation(a, b); 
    } 
  
    public static void main(String args[]) 
    { 
        FuncInter1 add = (int x, int y) ->(int)Math.pow(x,y); 
  
        FuncInter1 multiply = (int x, int y) -> x * y; 
        LamdaAdd  tobj = new LamdaAdd (); 
  
        System.out.println("power Value is " + 
                          tobj.operate(6, 3, add)); 
  
        System.out.println("Multiplication is " + 
                          tobj.operate(6, 3, multiply)); 
  
        FuncInter2 fobj = message ->System.out.println("Hello "
                                                 + message); 
        fobj.sayMessage("Geek"); 
    } 
} 
*/