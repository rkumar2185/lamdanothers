import java.util.Scanner;
import java.util.function.BiFunction;
import java.util.regex.Pattern;

//import com.cg.emp.exception.EmployeeException;

public class AcceptUserNameLambda {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Your Lovely userName:");
		String str1 = sc.nextLine();
		System.out.println("whats your secret:");
		String str2 = sc.nextLine();

		BiFunction<String,String,Boolean> validd = (user ,pass)->{
			String namePatter="[A-Z][a-z]+";
            String passPatter="[0-9][a-z]+" ;
			if(Pattern.matches(namePatter, user) && Pattern.matches(passPatter, pass))
			{
				return true;
			}
			else
			{
				/*System.out.println(" Invalid input "
						+ " Only Char are  allowed  and should start"
						+ " with Capital ex. Umeshbhai");*/
				return false;
			}
			//return null;
			
		};
		
		System.out.println(validd.apply(str1,str2));
		
	}

}
