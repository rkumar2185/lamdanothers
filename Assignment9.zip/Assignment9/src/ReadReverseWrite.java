import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadReverseWrite {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        // 9.1 Read and Reverse and Write content file

        FileReader fr;
        try {
            fr = new FileReader("content.txt");

            BufferedReader br = new BufferedReader(fr);
            String line;
            FileWriter fw;
            fw = new FileWriter("outputContent.txt");

            BufferedWriter bw = new BufferedWriter(fw);
            String s = null;
            char[] a = new char[500];
            while ((line = (br.readLine())) != null) {

                s = line.toString();

            }
            a = s.toCharArray();
            for (int i = a.length - 1; i >= 0; i--) {
                bw.write(a[i]);
            }
            bw.close();
            System.out.println("The contents have been copied");

            // 9.2 Display Even Numbers only
            System.out.println("Display Even Numbers only");
            FileReader fr2 = new FileReader("numbers.txt");
            BufferedReader br2 = new BufferedReader(fr2);
            String str;
            String s2 = null;
            String[] a2 = new String[6];
            while ((str = br2.readLine()) != null) {
                s2 = str.toString();
            }
            a2 = s2.split(",");
            int i = 0;
            while (i < a2.length) {
                System.out.println(a2[i]);
                i = i + 2;
            }

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
