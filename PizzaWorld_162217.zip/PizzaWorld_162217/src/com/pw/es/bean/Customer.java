package com.pw.es.bean;

public class Customer {
	private String custName;
	private String address;
	private String phone;
	
	
	//constructor
	public Customer(String custName, String address, String phone) {
		super();
		this.custName = custName;
		this.address = address;
		this.phone = phone;
	}
	//getter and setter
	public String getCustName() {
		return custName;
	}
	public String getAddress() {
		return address;
	}
	public String getPhone() {
		return phone;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	//tostring()
	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", address=" + address
				+ ", phone=" + phone + "]";
	}
	
	
	

}
