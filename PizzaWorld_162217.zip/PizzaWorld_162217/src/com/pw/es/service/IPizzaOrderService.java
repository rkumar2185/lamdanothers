package com.pw.es.service;

import java.util.Map;

import com.pw.es.bean.Customer;
import com.pw.es.bean.PizzaOrder;
import com.pw.es.exception.PizzaException;

public interface IPizzaOrderService {
	public String addEmployee(Customer ee)throws
	PizzaException;
	public int placeOrder(Customer customer,PizzaOrder pizza)throws PizzaException;
	public PizzaOrder getOrderDetails(int orderid)throws PizzaException;
	public boolean validatePhnNo(String phnNo) throws PizzaException;
	//public Map<Integer, com.pw.es.ui.Customer> fetchAllEmp();
	public Map<Integer, Customer> fetchAllEmp();

}
