package com.pw.es.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.pw.es.bean.Customer;
import com.pw.es.bean.PizzaOrder;
import com.pw.es.dao.IPizzaOrderDAO;
import com.pw.es.dao.PizzaorderDao;
import com.pw.es.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {
	 IPizzaOrderDAO empDao = new  PizzaorderDao();
	    
	    /*public (){
	    	empDao = new  PizzaorderDao();
	    }*/

	@Override
	public int placeOrder(Customer customer,PizzaOrder pizza) throws PizzaException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid)
			throws PizzaException {
		// TODO Auto-generated method stub
		return null;
	}
	
	 @Override
	    public boolean validatePhnNo(String cstmrPhoneNo)
	            throws PizzaException {
	        // TODO Auto-generated method stub
	        String mobilePattern = "^[1-9]{1}[0-9]{9}$";
	        if (Pattern.matches(mobilePattern, cstmrPhoneNo)) {
	            return true;
	        } else {
	            throw new PizzaException("Invalid Mobile Number");
	        }
	    }

	@Override
	public String addEmployee(Customer ee) throws PizzaException {
		// TODO Auto-generated method stub
		 return empDao.addEmployee(ee);
	}
	 
	    public Map<Integer,Customer> fetchAllEmp() {
	        return empDao.fetchAllEmp();
	    }
	    
	
}