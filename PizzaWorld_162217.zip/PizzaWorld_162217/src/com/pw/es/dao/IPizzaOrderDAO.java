package com.pw.es.dao;
import java.util.Map;

import com.pw.es.bean.Customer;
import com.pw.es.bean.PizzaOrder;
import com.pw.es.exception.PizzaException;

public interface IPizzaOrderDAO {

	
		public int placeOrder(Customer customer,PizzaOrder pizza)throws PizzaException;
		public PizzaOrder getOrderDetails(int orderid)throws PizzaException;
		public String addEmployee(Customer ee);
		Map<Integer, Customer> fetchAllEmp();

	}




