package com.pw.es.exception;

	public class PizzaException extends Exception 
	{
		public  PizzaException(String msg)
		{
			super(msg);
		}

	}



