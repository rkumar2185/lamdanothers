package com.pw.es.junit;

	import static org.junit.Assert.*;

	import java.time.LocalDate;







	import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.pw.es.bean.Customer;
import com.pw.es.dao.PizzaorderDao;
import com.pw.es.exception.PizzaException;


	public class CustomerJunit {
		static  PizzaorderDao empdao = null;

		@BeforeClass
		public static void setUpBeforeClass() throws Exception {
			empdao = new PizzaorderDao();
		}

		@AfterClass
		public static void tearDownAfterClass() throws Exception {
			System.out.println("this function is called once"
			           +"after the execution of all tets cases");
		}

		@Before
		public void setUp() throws Exception {
		}

		@After
		public void tearDown() throws Exception {
		}

		/*@Test
		public void addEmpTest() throws PizzaException {
			Assert.assertEquals(111, empdao.addEmployee(new Customer("holy", "aaa",
					"789562133")));
		}
		*/
		@Test
		public void testfetchAllEmp()
		{
			Assert.assertNotNull(empdao.fetchAllEmp());
		}


	}



