public class UserValid {
    String name;
    public UserValid(String name)
    {
        this.name=name;
    }

public void isValid()
{
char[] user=name.toCharArray();
int l=user.length;
int v=l-4;
int i=v;
if(l>=12)
{
if(user[i]=='_' &&user[i+1]=='j' && user[i+2]=='o'&&user[i+3]=='b')

{
System.out.println("Username Valid");
}
else
    System.out.println("Username Invalid");
}

else
{
System.out.println("Username Invalid"); 
}
}
}