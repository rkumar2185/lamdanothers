package ZonePro;

import java.util.Scanner;

public class MainCountryZone {

    public static void main(String[] args) {
        System.out.println("Enter your zone Id");
        System.out.println("1. America/New_York");
        System.out.println("2. Europe/London");
        System.out.println("3. Asia/Tokyo");
        System.out.println("4. US/Pacific");
        System.out.println("5.  Africa/Cairo");
        System.out.println("6. Australia/Sydney");
        Scanner sc=new Scanner(System.in);
        int selectedId=sc.nextInt();
        CountryZone c=new CountryZone(selectedId);
        c.fetchCurrentDate();

    }

}