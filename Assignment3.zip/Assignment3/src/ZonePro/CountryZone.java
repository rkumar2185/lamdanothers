package ZonePro;


import java.time.ZoneId;
import java.time.ZonedDateTime;

public class CountryZone {
int zoneId;

public CountryZone(int zoneId) {
    super();
    this.zoneId = zoneId;
}
public void fetchCurrentDate()
{
    switch(zoneId)
    {
    case 1:{
        ZoneId zoneId = ZoneId.of("America/New_York");
        ZonedDateTime zonedDateTime = ZonedDateTime.now(zoneId);
        System.out.println(zonedDateTime);
        break;
    }
    case 2:{
        ZoneId zoneId = ZoneId.of("Europe/London");
        ZonedDateTime zonedDateTime = ZonedDateTime.now(zoneId);
        System.out.println(zonedDateTime);
        break;
    }
    case 3:{
        ZoneId zoneId = ZoneId.of("Asia/Tokyo");
        ZonedDateTime zonedDateTime = ZonedDateTime.now(zoneId);
        System.out.println(zonedDateTime);break;
    }
    case 4:{
        ZoneId zoneId = ZoneId.of("US/Pacific");
        ZonedDateTime zonedDateTime = ZonedDateTime.now(zoneId);
        System.out.println(zonedDateTime);break;
    }
    case 5:{
        ZoneId zoneId = ZoneId.of("Africa/Cairo");
        ZonedDateTime zonedDateTime = ZonedDateTime.now(zoneId);
        System.out.println(zonedDateTime);break;
    }
    case 6:{
        ZoneId zoneId = ZoneId.of("Australia/Sydney");
        ZonedDateTime zonedDateTime = ZonedDateTime.now(zoneId);
        System.out.println(zonedDateTime);break;
    }
    
    
    }

}
}