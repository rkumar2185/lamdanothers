import java.util.Scanner;

public class CheckMainString {

    public static void main(String[] args) {
        System.out.println("Enter the string to check if it is positive or not");
        Scanner sc=new Scanner(System.in);
        String p=sc.next();
        positiveString ps = new positiveString();
        ps.checkString(p);
    }

}