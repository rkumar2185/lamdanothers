public class ProductDate {
    int year;
    int month;
    int day;
    int waryear;
    int warmonth;
    int resultYear;
    int resultMonth;
    public void setProductDate(int year,int month,int day)
    {
        this.year=year;
        this.month=month;
        this.day=day;
    }
    public void setProductWaranty(int waryear,int warmonth)
    {
        if(warmonth>=12)
        {
            this.waryear=waryear+waryear/12;
            this.warmonth=warmonth%12;
        }
        else{
        this.waryear=waryear;
        this.warmonth=warmonth;
    }
    }
    public void getExpiryDate()
    {
    int addyear=month+warmonth;
    if(addyear>12)
    {
        resultMonth=addyear-12;
        resultYear=year+waryear+1;
        System.out.println("Expiry Date is "+day+"/"+resultMonth+"/"+resultYear);
    }
    else{ 
        if(addyear==12)
    {
        resultYear=year+1;
        resultMonth=month+warmonth;
        System.out.println("Expiry Date is "+day+"/"+resultMonth+"/"+resultYear);
    }
    else
    {
        resultMonth=month+warmonth;
        resultYear=year+waryear;
        System.out.println("Expiry Date is "+day+"/"+resultMonth+"/"+resultYear);
    }
    }
}
}