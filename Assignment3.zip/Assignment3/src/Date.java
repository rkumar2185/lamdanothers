import java.time.LocalDate;
import java.time.Period;

public class Date {
int year;
int month;
int day;
public Date(int year,int month,int day)
{
    this.year=year;
    this.month=month;
    this.day=day;
}
public void getDuration()
{
    LocalDate pdate = LocalDate.of(year, month, day);
    LocalDate now = LocalDate.now();

    Period diff = Period.between(pdate, now);

 System.out.printf("\nDifference is %d years, %d months and %d days old\n\n", 
                diff.getYears(), diff.getMonths(), diff.getDays()); 
}
}