import java.util.Scanner;
import java.util.regex.Pattern;

/*You are asked to create an application for registering the details of
jobseeker. The requirement is: Username should always end with _job
and there should be atleast minimum of 8 characters to the left of _job.
Write a function to validate the same. Return true in case the validation is passed. 
In case of validation failure return false. */

public class StringValidation {
	

	private void ValidateApplication() {
		System.out.println("Please Enter Your Lovely Username :");
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		String fnPattern ="[A-Za-z0-9]{7,29}+_job$";//+ one more occurance
		if(Pattern.matches(fnPattern, str))
		{
			System.out.println("Valid  UserName");
		}
		else
		{
			System.out.println("Invalid!!!!!!!!");
		}
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringValidation sv = new StringValidation();
		sv.ValidateApplication();

	}


}
