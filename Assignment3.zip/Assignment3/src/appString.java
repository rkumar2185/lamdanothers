
public class appString {
    int choice;
    String name;
/*public appString(int choice,String name)
{
this.choice=choice;
this.name=name;
}*/
public void switchfunction(int choice, String name)
{
    
    switch(choice)
    {
    case 1:{
        doOperation(name);
    break;
    }
    case 2:{
        replaceOdd(name);
        break;
    }
    case 3:{
        removeDuplicate(name);
        break;
    }
    case 4:{
        toUpperCase(name);
        break;
    }
    }
    }
public void doOperation(String p)
{
        String s= new String(p);
        String s2=s.concat(p);
        System.out.println(s2);
        

}
public void replaceOdd(String p)
{
    char[] c=p.toCharArray();
    int i;
for(i=0;i<=c.length-1;i++)
{
    if(i%2==0)
    {
        c[i]='#';
    }
    
    }
System.out.println(c);
}
public void removeDuplicate(String p)
{ 
    char[] c=p.toCharArray();
    int end = c.length;

    for (int i = 0; i < end; i++) {
        for (int j = i + 1; j < end; j++) {
            if (c[i] == c[j]) {                  
                int shiftLeft = j;
                for (int k = j+1; k < end; k++, shiftLeft++) {
                    c[shiftLeft] = c[k];
                }
                end--;
                j--;
            }
        }
    }

    int[] whitelist = new int[end];
    for(int i = 0; i < end; i++){
        whitelist[i] = c[i];
    }
   
    
    }
public void toUpperCase(String p)
{
    char[] c=p.toCharArray();
    int i;
    for(i=0;i<c.length;i++)
    {
        if(i%2==0)
        { 
            char currentletter;
            int q;
            currentletter=c[i];
            if((currentletter>='a')&&(currentletter <='z'))
            {
                c[i]=(char)(c[i]-32);
            }
        }
    }
    System.out.println(c);
    }
}