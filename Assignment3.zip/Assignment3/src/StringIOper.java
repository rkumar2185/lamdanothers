
public class StringIOper {
	
	
	//Add the String to itself 
	public String AddString(String str)
	{
		str = str + str ;
		return str;
	}
	
	
	//Replace odd positions with # 
	public String ReplaceOdd(String str)
	{
	      
		for (int i=0; i < str.length(); i++){
		        if (i % 2 != 0){
		          str = str.substring(0,i-1) + "#" + str.substring(i, str.length());
		        }
			
		}
		return str;
	}

	//Remove duplicate characters in the String 
	
	public void RemDupl(String str)
	{
		String output = new String();

        for (int i = 0; i < str.length(); i++) {
            for (int j = 0; j < output.length(); j++) {
                if (str.charAt(i) != output.charAt(j)) {
                    output = output + str.charAt(i);
                }
            }
        }

        System.out.println(output);

	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringIOper so = new StringIOper();
		String str = "Cool";
		System.out.println(so.AddString(str));
		
		System.out.println(so.ReplaceOdd(str));
		
	    so.RemDupl(str);

	}

}
