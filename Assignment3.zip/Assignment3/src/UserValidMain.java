import java.util.Scanner;

public class UserValidMain {

    public static void main(String[] args) {
        System.out.println("Enter the username");
        Scanner sc=new Scanner(System.in);
        String username=sc.next();
        UserValid uv=new UserValid(username);
        uv.isValid();
        
    }

}