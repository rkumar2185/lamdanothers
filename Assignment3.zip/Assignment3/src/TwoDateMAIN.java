import java.util.Scanner;

public class TwoDateMAIN {

    public static void main(String[] args) {
System.out.println("Enter the year,month,day of first date");
Scanner sc=new Scanner(System.in);
int year=Integer.parseInt(sc.next());
int month=Integer.parseInt(sc.next());
int day=Integer.parseInt(sc.next());
System.out.println("Enter the year,month,day of second date");
Scanner sp=new Scanner(System.in);
int year1=Integer.parseInt(sc.next());
int month1=Integer.parseInt(sc.next());
int day1=Integer.parseInt(sc.next());
twoDate td= new twoDate();
td.setDateOne(year,month,day);
td.setDateTwo(year1, month1, day1);
td.getDuration();


    }

}
