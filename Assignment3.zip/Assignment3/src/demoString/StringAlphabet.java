package demoString;

import java.util.Arrays; 

public class StringAlphabet {
String name;
public void getConversion(String s)
{
    name=s;
    int i;
    char q;
    char[] a=name.toCharArray();
    Arrays.sort(a);
    int n=a.length;
    if(n%2==0)
    {
    for(i=0;i<n/2;i++)
    {
        char currentletter=a[i];
        if((currentletter>='a')&&(currentletter <='z'))
        {
            a[i]=(char)(a[i]-32);
        }
    }
    for(i=n/2;i<n-1;i++)
    {
        char currentletter=a[i];
        if((currentletter>='A')&&(currentletter <='Z'))
        {
            a[i]=(char)(a[i]+32);
        }
    }
    
    System.out.println(a);
    }
    else
    {
        for(i=0;i<(n/2)+1;i++)
        {
            char currentletter=a[i];
            if((currentletter>='a')&&(currentletter <='z'))
            {
                a[i]=(char)(a[i]-32);
            }
        }
        for(i=(n/2)+1;i<n-1;i++)
        {
            char currentletter=a[i];
            if((currentletter>='A')&&(currentletter <='Z'))
            {
                a[i]=(char)(a[i]+32);
            }
        }
        
        System.out.println(a);
    }
}
}