package demoString;

import java.util.Scanner;

public class MainStringAlpha {

    public static void main(String[] args) {
        System.out.println("Enter the String to convert into cases");
        Scanner sc= new Scanner(System.in);
        String p=sc.next();
        StringAlphabet sa= new StringAlphabet();
        sa.getConversion(p);
    }

}
