import java.util.Scanner;

public class ProductDateMain {

    public static void main(String[] args) {
System.out.println("Enter the purchase date in format(dd-yy-mm)");
Scanner sc=new Scanner(System.in);
int day=Integer.parseInt(sc.next());
int year=Integer.parseInt(sc.next());
int month=Integer.parseInt(sc.next());

System.out.println("Enter the duration of warranty in format (yy-mm)");
Scanner sp=new Scanner(System.in);
int waryear=Integer.parseInt(sp.next());
int warmonth=Integer.parseInt(sp.next());
ProductDate pd = new ProductDate();
pd.setProductDate(year, month, day);
pd.setProductWaranty(waryear,warmonth);
pd.getExpiryDate();
    }

}