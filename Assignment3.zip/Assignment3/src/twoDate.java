import java.time.LocalDate;
import java.time.Period;

public class twoDate {
    int year;
    int month;
    int day;
    int year1;
    int month1;
    int day1;
    public void setDateOne(int year,int month,int day)
    {
        this.year=year;
        this.month=month;
        this.day=day;
    }
    public void setDateTwo(int year1,int month1,int day1)
    {
        this.year1=year1;
        this.month1=month1;
        this.day1=day1;
    }
    public void getDuration()
    {
        
        LocalDate pdate = LocalDate.of(year, month, day);
        LocalDate qdate = LocalDate.of(year1, month1, day1);
         Period diff = Period.between(pdate, qdate);
         System.out.printf("\nDifference is %d years, %d months and %d days old\n\n", 
                    diff.getYears(), diff.getMonths(), diff.getDays());
    }
}
