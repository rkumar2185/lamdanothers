import java.util.Arrays;
public class positiveString {
String name;
static int  count1=0;
public void checkString(String name)
{
    this.name=name;
    int count=0;
    int j;
    int i;
    char[] c=name.toCharArray();
    int f=c.length-1;
    for(i=0;i<c.length;i++)
    {
    for(j=i+1;j<c.length;j++)
        
    {
        if((int)c[i]< (int)c[j])
        {
            count1++;
            
        }
        else
        {
            System.out.println("Negative String");
        }
        }

        }
    if(count1==((f*(f+1))/2))
    {
        System.out.println("Postivie String");
}
}
}
    
    