import java.time.*;
import java.util.*;

public class DateMain {  
   public static void main(String[] args)
    {
       System.out.println("Enter the year,month,date");
       Scanner sc= new Scanner(System.in);
       int year=Integer.parseInt(sc.next());
       int month=Integer.parseInt(sc.next());
       int day=Integer.parseInt(sc.next());
        Date d= new Date(year,month,day);
        d.getDuration();
  }
}