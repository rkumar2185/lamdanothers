public class PersonDetails {

    private String firstName;
    private String lastName;
    private int age;
    private int weight;
    private long num;
    private String gender;
    
    public PersonDetails(String firstName, String lastName, String gender,
            int age, int weight,long num) {
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.age = age;
        this.weight = weight;
        this.num=num;
    }
    public long getNum() {
        return num;
    }
    public void setNum(long num) {
        this.num = num;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public int getWeight() {
        return weight;
    }
    public void setWeight(int weight) {
        this.weight = weight;
    }
    @Override
    public String toString() {
        return " PersonDetails \n ____________\n \n firstName-- " + firstName + " \n lastName-- "
                + lastName + " \n gender-- " + gender+  " \n age--" + age
                + " \n weight--" + weight + ""+ "\n Phone number--" + num;
    }
    
    
}