public class NegativePositive {

    
        public static void main(String[] args) {
         
            String Num1= args[0];
            int  a = Integer.parseInt(Num1);
            if (a>0)
            {
                
            
        System.out.println("Number is positive "+a);
            }
            else
            {
                System.out.println("Number is negative"+a);
            }
        }
    }