import java.util.Scanner;



public class Main {
    
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        System.out.println("Enter the phone no. of the person");
        Scanner sc= new Scanner(System.in);
        long num=sc.nextLong();
        System.out.println("Enter the Gender");
        Scanner s= new Scanner(System.in);
        String gender = s.next();
        PersonDetails det = new PersonDetails("Ravi", "Gupta", /*'M' */ gender, 22,67,num);
        System.out.println(det);
    }

}