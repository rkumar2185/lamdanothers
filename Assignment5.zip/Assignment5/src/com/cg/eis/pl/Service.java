package com.cg.eis.pl;
import com.cg.eis.bean.*;

import java.util.Scanner;

import Main.MainEmployee;

import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.Public;

public class Service implements EmployeeService{

	

	@Override
	public String Insurancescheme(long salary) {
		// TODO Auto-generated method stub
		if (salary> 5000 && salary <20000)
		{
			return "Scheme"+ "C";
		}
		else if (salary >= 20000 && salary < 40000)
		{
			return "Scheme"+ "B";
		}
		else if (salary >= 40000 )
		{
			return "Scheme"+ "A";
		}
		if (salary < 5000 )
		{
			return "Scheme"+ "NO Scheme";
		}
		
	}

	@Override
	public void EmployeeDetails() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int emp_Id = sc.nextInt();
		String emp_Name = sc.next();
		long salary = sc.nextLong();
		String designation = sc.next();
		String Insurance_Scheme = sc.next();
		
		
	}


	@Override
	public void DisplayDetails(MainEmployee  me) {
		
		// TODO Auto-generated method stub
		return "Emplopyee [emp_Id=" + emp_Id + ", emp_Name=" + emp_Name
				+ ", salary=" + salary + ", designation=" + designation
				+ ", Insurance_Scheme=" + Insurance_Scheme + "]";
		
		
	}
	

}
