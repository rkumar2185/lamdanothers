/*
com.cg.eis.bean  In this package, create �Employee� 
class with different attributes such as
id, name, salary, designation, insuranceScheme. */

package com.cg.eis.bean;

public class Emplopyee {
	int emp_Id;
	String emp_Name;
	long salary;
	String designation;
	String Insurance_Scheme;
	
	public Emplopyee(int emp_Id, String emp_Name, long salary,
			String designation, String insurance_Scheme) {
		super();
		this.emp_Id = emp_Id;
		this.emp_Name = emp_Name;
		this.salary = salary;
		this.designation = designation;
		Insurance_Scheme = insurance_Scheme;
	}

	public int getEmp_Id() {
		return emp_Id;
	}

	public String getEmp_Name() {
		return emp_Name;
	}

	public long getSalary() {
		return salary;
	}

	public String getDesignation() {
		return designation;
	}

	public String getInsurance_Scheme() {
		return Insurance_Scheme;
	}

	public void setEmp_Id(int emp_Id) {
		this.emp_Id = emp_Id;
	}

	public void setEmp_Name(String emp_Name) {
		this.emp_Name = emp_Name;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public void setInsurance_Scheme(String insurance_Scheme) {
		Insurance_Scheme = insurance_Scheme;
	}

	@Override
	public String toString() {
		return "Emplopyee [emp_Id=" + emp_Id + ", emp_Name=" + emp_Name
				+ ", salary=" + salary + ", designation=" + designation
				+ ", Insurance_Scheme=" + Insurance_Scheme + "]";
	}
	
	
	
	

}
