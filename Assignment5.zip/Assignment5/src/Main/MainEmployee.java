package Main;

import com.cg.eis.pl.Service;

public class MainEmployee extends Service {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainEmployee  me = new MainEmployee();
		me.DisplayDetails(me);
		me.EmployeeDetails();
		long salary = 0;
		me.Insurancescheme(salary); 

	}


}
