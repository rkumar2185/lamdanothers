import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class TestDate {

	/*@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}*/
	
	/*@Test
	public void testGetFullName() {
		System.out.println("from TestPerson2");
		Person per1 = new Person("Ravi","King");
		assertEquals("Ravi King", per1.getFullName());
	}
	*/
	
	
	@Test
	public void testgetIntDay(){
		System.out.println("From date");
		Date d = new Date(4,10,2018);
		Assert.assertEquals(4-10-2018, d.getDate());
	}
	

}
