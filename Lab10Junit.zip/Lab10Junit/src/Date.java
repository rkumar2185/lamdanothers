
public class Date {
	int intDay;
	int intmonth;
	int intyear;
	
	

	public Date(int intDay, int intmonth, int intyear) {
		//super();
		this.intDay = intDay;
		this.intmonth = intmonth;
		this.intyear = intyear;
	}
	
	/*
	public String getFullName() {
		String first = (this.firstName != null) ? this.firstName : "?";
		String last = (this.lastName != null) ? this.lastName : "?";
		return first + "" + last;
	}
*/
	public int getDate(){
		int day = (this.intDay != 0) ? this.intDay :0;
		int month = (this.intmonth != 0) ? this.intmonth :0;
		int year = (this.intyear != 0) ? this.intyear :0;
		return day+month+year;
	}

	public int getIntDay() {
		return intDay;
	}




	public int getIntmonth() {
		return intmonth;
	}




	public int getIntyear() {
		return intyear;
	}




	public void setIntDay(int intDay) {
		this.intDay = intDay;
	}




	public void setIntmonth(int intmonth) {
		this.intmonth = intmonth;
	}




	public void setIntyear(int intyear) {
		this.intyear = intyear;
	}




	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}




	@Override //converts date obj to string
	public String toString() {
		return "Date [intDay=" + intDay + ", intmonth=" + intmonth
				+ ", intyear=" + intyear + "]";
	}
	

}
