package Junit;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Test;

public class Testperson2 {

    @Test
    public void test() {
        System.out.println("Enter first Name");
        Scanner sc=new Scanner(System.in);
        String firstName=sc.next();
        System.out.println("Enter last Name");
        Scanner sp=new Scanner(System.in);
        String lastName=sp.next();
        System.out.println("Enter gender");
        Scanner sq=new Scanner(System.in);
        String gender=sq.next();
        System.out.println("Enter age");
        Scanner st=new Scanner(System.in);
        int age=st.nextInt();
        System.out.println("Enter weight");
        Scanner so=new Scanner(System.in);
        double weight=so.nextFloat();
        
        Person p=new Person(firstName,lastName,gender,age,weight);
        assertEquals(age,p.getAge());
        assertEquals(weight,p.getWeight());
        assertEquals(gender,p.getGender());
        assertEquals(lastName,p.getLastname());
        assertEquals(firstName,p.getFirstname());
    }

}