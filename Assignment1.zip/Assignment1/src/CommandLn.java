
 /*Write a program to accept a number from user as a command line argument
 and check whether the given number is positive or negative number. 
*/
public class CommandLn {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		 String s = args[0];
		 String s1 = args[1];
		 
		//converting String to integer
		 int y = Integer.parseInt(s);
		 int x = Integer.parseInt(s1);
		 
		 if(x>0 && y>0)
		 
			 System.out.println("given numbers are positive");
			 else 
		 
			 /*System.out.println(x);
		     System.out.println(y);*/
			 System.out.println("given numbers are negative");
		 
		 
		 

		
	}

}
