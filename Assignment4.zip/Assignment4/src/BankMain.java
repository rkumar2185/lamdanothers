public class BankMain {

     
        
    static Account acc;
    static Account acc1;

    public static void main(String[] args) {
        Person p= new Person("Smith",20.0F);
        Person q= new Person("Kathy",21.0F);
        acc = new Account(2000, p);
        acc1 = new Account(3000, q);
        acc.deposit(2000);
        acc1.withdraw(2000);
                
        Object obj = acc.toString();
        Object obj1 = acc1.toString();
                
        System.out.println(obj);
        System.out.println(obj1);
                
                

            }
    }