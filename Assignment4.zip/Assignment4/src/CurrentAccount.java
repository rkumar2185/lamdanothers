
    public class CurrentAccount extends Account
    {
        double overdraft_Limit = -1000;

        public CurrentAccount(double balance, Person accHolder) {
            super(balance, accHolder);
        }
        @Override
        public void withdraw(double amount)
        {
            if(overdraft_Limit<=amount)
            {
                balance = balance-amount;
                setBalance(balance);
            }
            else
            {
                System.out.println("Sorry.The amount can't be withdraw");
            }
        }
        @Override
        public String toString() {
            return "CurrentAccount [overdraft_Limit=" + overdraft_Limit + "]";
        }
        
        

    }


