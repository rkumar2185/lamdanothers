public class SavingAccount extends Account {
        
        final double minBal = 500;
        
        public SavingAccount(double balance, Person accHolder)
        {
            super(balance, accHolder);
        }
        @Override
        public void withdraw(double amount)
        {
            if(amount>=minBal)
            {
                balance = balance-amount;
                setBalance(balance);
            }
        }
        
        @Override
        public String toString()
        {
            return super.toString()+ "SavingAccount [minBal=" + minBal + "]";
        }

    }
