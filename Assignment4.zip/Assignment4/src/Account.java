
public class Account {
     
    long accNum;
    double balance;
    

    Person accHolder;
    
    public void deposit(double amount)
    {
        balance = amount + balance;
        setBalance(balance);
            
    }
    
    public Account(double balance, Person accHolder) {
        super();
        setAccNum(accNum);
        this.balance = balance;
        this.accHolder = accHolder;
    }

    public void withdraw(double amount)
    {
        balance = balance - amount;
        setBalance(balance);
    }
    
  

    public double getBalance() {
        return balance;
    }

    public Person getAccHolder() {
        return accHolder;
    }

    
    
   

    public void setAccNum(long accNum) {
        this.accNum = (long) (99999999*(Math.random()));
    }
    
    public void setAccHolder(Person accHolder) {
        this.accHolder = accHolder;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    
    @Override
    public String toString() {
        return "Account [accNum=" + accNum + ", balance=" + balance
                + ", accHolder=" + accHolder + "]";
    }
}