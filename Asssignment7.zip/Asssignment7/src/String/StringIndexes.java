package String;

import java.util.ArrayList;
import java.util.List;

public class StringIndexes {
String name1;
String name2;
public StringIndexes(String name1, String name2) {
    super();
    this.name1 = name1;
    this.name2 = name2;
}
public void doIndexOperation()
{
List<Object> lis1=new ArrayList<>();
List<Object> lis2=new ArrayList<>();
for(int i=0;i<name1.length();i++)
{
lis1.add(name1.charAt(i));  

}
for(int j=0;j<name2.length();j++)
{
    lis2.add(name2.charAt(j));
    
}
for(int k=0;k<lis1.size();k++)
{
    if(k%2!=0)
    {
        lis1.remove(k);
        lis1.add(k,lis2.get(k));
    }
}
System.out.println(lis1);
}
}
