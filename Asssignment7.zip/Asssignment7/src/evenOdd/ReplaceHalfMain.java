package evenOdd;

import java.util.Scanner;

public class ReplaceHalfMain {

    public static void main(String[] args) {
        System.out.println("Enter first String");
        Scanner sc=new Scanner(System.in);
        String name1=sc.next();
        System.out.println("Enter second String");
        Scanner sp=new Scanner(System.in);
        String name2=sp.next();
        
        ReplaceHalf rh=new ReplaceHalf(name1,name2);
        rh.repString();
    }

}