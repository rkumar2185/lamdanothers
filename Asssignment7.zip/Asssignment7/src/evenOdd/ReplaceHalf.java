package evenOdd;

import java.util.ArrayList;
import java.util.List;

public class ReplaceHalf {
    String name1;
    String name2;
    public ReplaceHalf(String name1, String name2) {
        super();
        this.name1 = name1;
        this.name2 = name2;
    }
        public void repString()
        {
            List<Object> lis1=new ArrayList<>();
            List<Object> lis2=new ArrayList<>();
            List<Object> lis3=new ArrayList<>();
            List<Object> lis4=new ArrayList<>();
            
            for(int i=0;i<name1.length();i++)
            {
                lis1.add(name1.charAt(i));
                
            }
            for(int j=0;j<name2.length();j++)
            {
                lis2.add(name2.charAt(j));
                
            }
            int Size=lis2.size();
            for(int k=0;k<Size/2;k++)
            {
                lis3.add(lis2.get(k));
                
            }
            for(int q=0;q<lis1.size();q++)
            {
            lis3.add(lis1.get(q));
            }
            for(int p=Size/2;p<lis2.size();p++)
            {
                lis4.add(lis2.get(p));
                
            }
            for(int c=0;c<lis4.size();c++)
            {
            lis3.add(lis4.get(c));
            }
            String listString = "";

            for (Object s : lis3)
            {
                listString += s + "\t";
            }
            String lineWithoutSpaces = listString.replaceAll("\\s+","");
            System.out.println(lineWithoutSpaces);
            
        }
    }