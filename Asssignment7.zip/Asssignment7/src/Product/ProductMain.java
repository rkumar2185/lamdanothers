package Product;

import java.util.Scanner;



public class ProductMain {
    public static void main(String[] args)
    {
        System.out.println("Enter the no. of products you want to sort");
        Scanner sc=new Scanner(System.in);
        int size=sc.nextInt();
        String pro[]=new String[size];
        System.out.println("enter the elements");
        for(int i=0;i<pro.length;i++)
        {
            Scanner sp=new Scanner(System.in);
            pro[i]=sp.next();
        }
        Product p=new Product();
        p.getSorted(pro);
        
    }

    
}