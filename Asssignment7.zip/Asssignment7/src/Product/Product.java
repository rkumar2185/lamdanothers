package Product;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Product {

public void getSorted(String[] c)
{
    List<String> lis=new ArrayList<>();
    for(int i=0;i<c.length;i++)
    {
        lis.add(c[i]);
        
    }
    Collections.sort(lis);
for(int j=0;j<lis.size();j++)
{
System.out.println(lis.get(j)); 
}
    
    }
}
