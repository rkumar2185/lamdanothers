package Reverse;
import java.util.Scanner;

public class ReverseSortMain {

    public static void main(String[] args) {
        System.out.println("Enter the number of elements you want to Reverse");
        Scanner sc=new Scanner(System.in);
        int size=sc.nextInt();
        int a[]=new int[size];
        System.out.println("Enter the Elements");
        for(int i=0;i<size;i++)
        {
            Scanner sp=new Scanner(System.in);
            a[i]=sp.nextInt();
            
        }
        ReverseSort rs=new ReverseSort(a);
        Object[] myArray=rs.ReverseAndSort();
        for(int q=0;q<myArray.length;q++)
        {
        System.out.println(myArray[q]);
        }
    }

}
