package Reverse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReverseSort {
int[] b;

public ReverseSort(int[] b) {
    super();
    this.b = b;
}
public Object[] ReverseAndSort()
{
    
List<Integer> lis=new ArrayList<>();
List<Integer> lis2=new ArrayList<>();

for(int p=0;p<b.length;p++)
{
lis.add(b[p]);  
}
for(int j=0;j<lis.size();j++)
{
    int n=lis.get(j);
    int reversedNumber = 0;
    int  remainder;
     while(n != 0)
        {
            remainder = n%10;
            reversedNumber = reversedNumber*10 + remainder;
            n /= 10;
        }
    lis2.add(reversedNumber);
}
Collections.sort(lis2);
Object[] resultArray=lis2.toArray();
return resultArray;
}
}

