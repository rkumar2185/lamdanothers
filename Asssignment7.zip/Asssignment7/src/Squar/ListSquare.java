package Squar;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ListSquare {

    public void toSquare(int b[])
    {
        
        List<Integer> lis=new ArrayList<>();
        List<Integer> lis2=new ArrayList<>();
        for(int i=0;i<b.length;i++)
        {
            
            lis.add(b[i]);
        }
        for(int j=0;j<lis.size();j++)
        {
            lis2.add(lis.get(j)*lis.get(j));
            
        }
         HashMap<Integer, Integer> hmap = new HashMap<Integer, Integer>();
         for(int k=0;k<lis.size();k++)
         {
             hmap.put(lis.get(k), lis2.get(k));
             
         }
         System.out.println(hmap);
    }
}