package Squar;
import java.util.Scanner;

public class HashSetMain {

    public static void main(String[] args) {
System.out.println("Enter the size of array of numbers");
Scanner sc=new Scanner(System.in);
int size=sc.nextInt();
int a[]=new int[size];
System.out.println("Enter the elements");
        for(int i=0;i<size;i++)
        {
            Scanner sp=new Scanner(System.in);
            a[i]=sp.nextInt();
        }
        ListSquare ls=new ListSquare();
        ls.toSquare(a);
        
    }

}