package ReplAst;

import java.util.Scanner;

public class ReplaceAstMain {

    public static void main(String[] args) {
        System.out.println("Enter First String");
        Scanner sc=new Scanner(System.in);
        String name1=sc.next();
        System.out.println("Enter Second String");
        Scanner sp=new Scanner(System.in);
        String name2=sp.next();
        
        ReplaceAst si=new ReplaceAst(name1,name2);
        si.doReplaceAst();

    }

}
