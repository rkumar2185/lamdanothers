package ReplAst;

import java.util.ArrayList;
import java.util.List;

public class ReplaceAst {
    String name1;
    String name2;
    public ReplaceAst(String name1, String name2) {
        super();
        this.name1 = name1;
        this.name2 = name2;
    }
    public void doReplaceAst()
    {
        List<Object> lis1=new ArrayList<>();
        List<Object> lis2=new ArrayList<>();
        for(int i=0;i<name1.length();i++)
        {
            lis1.add(name1.charAt(i));
            
        }
        for(int j=0;j<name2.length();j++)
        {
            lis2.add(name2.charAt(j));
            
        }
        for(int k=0;k<lis1.size();k++)
        {
            for(int p=0;p<lis2.size();p++)
            {
                if(lis1.get(k)==lis2.get(p))
                {
                    lis1.remove(k);
                    lis1.add(k,'*');
                    
                }
                
                
            }
            
        }
        System.out.println(lis1);
    }
}
