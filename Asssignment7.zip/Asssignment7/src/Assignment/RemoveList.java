
package Assignment;

import java.util.ArrayList;
import java.util.List;

public class RemoveList {
String name1;
String name2;
public RemoveList(String name1, String name2) {
    super();
    this.name1 = name1;
    this.name2 = name2;
}

public void removeDuplicate()
{
    List<Object> l1=new ArrayList<>();
    for(int i=0;i<name1.length();i++)
    {
     l1.add(name1.charAt(i));
    }
    //*System.out.println(l1);*//
    
    List<Object> l2=new ArrayList<>();
    for(int i=0;i<name2.length();i++)
    {
     l2.add(name2.charAt(i));
    }
    //*System.out.println(l2);*//
l1.removeAll(l2);
    System.out.println(l1);
    
}
}