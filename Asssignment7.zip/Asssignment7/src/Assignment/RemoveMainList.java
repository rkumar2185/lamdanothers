
package Assignment;

import java.util.Scanner;

public class RemoveMainList {

    public static void main(String[] args) {
        System.out.println("Enter the first String: ");
        Scanner sc=new Scanner(System.in);
        String name1=sc.next();
        System.out.println("Enter the Second String: ");
        Scanner sp=new Scanner(System.in);
        String name2=sp.next();
        RemoveList rl=new RemoveList(name1,name2);
        rl.removeDuplicate();
    }

}